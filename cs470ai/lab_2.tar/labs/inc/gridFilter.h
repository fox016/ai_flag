const int MAX_GRID_SIZE = 800; // Max world dimensions
const double INIT_BELIEF = 0.20; // Initial belief of a cell being occupied
const double PROB_OBSTACLE = 0.85; // Belief at which a cell is considered an obstacle and should be avoided

class GridFilter
{
private:
	World* world;
	int updateCount;
	double grid[MAX_GRID_SIZE][MAX_GRID_SIZE];

	/*
	 * Draw probable obstacles
	 */
	void drawProbableObstacles(ostream &os)
	{
		int half = (int) floor(world->worldSize / 2.0);
		int x, y, worldX, worldY;

		os << "set xrange [-" << half << ": " << half << "]" << endl;
		os << "set yrange [-" << half << ": " << half << "]" << endl;
		os << "set style line 1 lc rgb '#0060ad' pt 5" << endl;
		os << "unset arrow" << endl;
		os << "unset key" << endl;
		os << endl;

		os << "plot '-' w p ls 1" << endl;
		for(x = 0; x < world->worldSize; x++)
		{
			for(y = 0; y < world->worldSize; y++)
			{
				if(grid[x][y] > 1 || grid[x][y] < 0)
				{
					cout << "Illegal grid value: grid[" << x << ", " << y << "] = " << grid[x][y] << endl;
					exit(1);
				}
				if(isProbableObstacle(x, y))
				{
					worldX = (int) (x - floor(world->worldSize / 2.0));
					worldY = (int) (y - floor(world->worldSize / 2.0));
					os << worldX << " " << worldY << endl;
				}
			}
		}
		os << "e" << endl;
	}
public:

	/*
	 * @param pos - true positive [0, 1]
	 * @param neg - true negative [0, 1]
	 * @param x - x-dimension of world grid
	 * @param y - y-dimension of world grid
	 */
	GridFilter(World* w)
	{
		world = w;
		updateCount = 0;

		if(world->truePositive < 0 || world->truePositive > 1 || world->trueNegative < 0 || world->trueNegative > 1)
		{
			cout << "Illegal true positive and/or true negative values" << endl;
			exit(1);
		}

		if(world->worldSize > MAX_GRID_SIZE)
		{
			cout << "MAX_GRID_SIZE too small: " << world->worldSize << endl;
			exit(1);
		}

		// Fill each cell of grid with initial belief
		int i, j;
		for(i = 0; i < MAX_GRID_SIZE; i++)
		{
			for(j = 0; j < MAX_GRID_SIZE; j++)
			{
				grid[i][j] = INIT_BELIEF;
			}
		}
	}

	/*
	 * Updates grid using sensor data (occgrid)
	 */
	void updateGrid(occgrid_t* occgrid)
	{
		int xStart = (int) (occgrid->xPos + floor(world->worldSize / 2.0));
		int yStart = (int) (occgrid->yPos + floor(world->worldSize / 2.0));
		int xEnd = xStart + occgrid->xDim;
		int yEnd = yStart + occgrid->yDim;

		cout << "xStart: " << xStart << endl;
		cout << "yStart: " << yStart << endl;
		cout << "xEnd: " << xEnd << endl;
		cout << "yEnd: " << yEnd << endl;

		char hit;
		double likelihood, prior, normalizer;
		int x, y;

		for(x = xStart; x < xEnd; x++)
		{
			for(y = yStart; y < yEnd; y++)
			{
				hit = occgrid->grid[x-xStart][y-yStart];
				prior = grid[x][y];
				if(hit == '0')
				{
					likelihood = (1 - world->truePositive);
					normalizer = ((1-world->truePositive) * grid[x][y]) + (world->trueNegative * (1-grid[x][y]));
				}
				else if(hit == '1')
				{
					likelihood = world->truePositive;
					normalizer = (world->truePositive * grid[x][y]) + ((1-world->trueNegative) * (1-grid[x][y]));
				}
				else
				{
					cout << "Illegal hit value: " << hit << endl;
					exit(1);
				}

				if(normalizer == 0)
					grid[x][y] = 1.0;
				else
					grid[x][y] = (likelihood * prior) / normalizer;

				// Make sure it is valid
				if(grid[x][y] < 0.0 || grid[x][y] > 1.0)
				{
					cout << "Illegal grid value: (" << x << ", " << y << ") = " << grid[x][y] << endl;
					cout << "Hit: " << hit << endl;
					cout << "Likelihood: " << likelihood << endl;
					cout << "Prior: " << prior << endl;
					cout << "Normalizer: " << normalizer << endl;
					exit(1);
				}
			}
		}

		updateCount++;
		cout << "Update count: " << updateCount << endl;

		if(updateCount > 20)
		{
			filebuf fb;
			fb.open("probable_obstacles.gpi", std::ios::out);
			ostream os(&fb);
			drawProbableObstacles(os);
			fb.close();
			updateCount = 0;
		}
	}

	/*
	 * Returns true if grid at cell (x, y) is probably occupied
	 * See PROB_OBSTACLE
	 */
	bool isProbableObstacle(int x, int y)
	{
		if(x > world->worldSize || x < 0 || y > world->worldSize || y < 0)
		{
			cout << "Invalid x or y parameter to isProbableObstacle:" << x << ", " << y << endl;
			cout << "worldsize: " << world->worldSize << endl;
			exit(1);
		}
		return grid[x][y] >= PROB_OBSTACLE;
	}
};
