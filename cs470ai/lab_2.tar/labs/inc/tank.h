class Tank
{
private:
	int index;

	vector<int> xHistory;
	vector<int> yHistory;

	FieldGenerator* fieldGen;
	World* world;
	BZRC* myTeam;

	int xTarget;
	int yTarget;
	bool goingUp;
	bool goingRight;

	int stuckIter;

	/*
	 * Repel previous locations
	 */
	void repelHistory()
	{
		unsigned int repelLoc = 10;
		if(xHistory.size() < repelLoc)
			return;

		unsigned int i;
		double repelStrength = 1.0;
		double strength = repelStrength;
		for(i = xHistory.size() - repelLoc; i < xHistory.size(); i++)
		{
			fieldGen->addField(new PotentialField(xHistory[i], yHistory[i], 20, 0, strength, REPEL));
			strength += repelStrength;
		}
	}

	/*
	 * @return true iff tank appears stuck
	 */
	bool isStuck()
	{
		unsigned int pastLoc = 20;
		if(xHistory.size() < pastLoc)
			return false;
	
		int margin = 50; // If haven't moved (margin, margin) in last pastLoc steps, return true
		unsigned int i;
		unsigned int prevPos = xHistory.size() - pastLoc;
		for(i = prevPos; i < xHistory.size(); i++)
		{
			if((abs(xHistory[i] - xHistory.back()) > margin) ||
				(abs(yHistory[i] - yHistory.back()) > margin))
			{
				return false;
			}
		}
		return true;
	}

	/*
	 * Create potential field in cardinal direction from
	 * last position to try to get unstuck
	 *
	 * @param gridFilter - Allows function to make tank avoid probable obstacles
	 */
	void getUnstuck(GridFilter* gridFilter)
	{
		// Try each cardinal direction for a certain number of iterations
		// before giving up and trying and trying a new cardinal direction.
		// Only do if stuckIter is greater than tryCount
		int tryCount = 15;
		int fieldDist = 200;
		int x = xHistory.back();
		int y = yHistory.back();
		if(stuckIter >= tryCount)
		{
			myTeam->shoot(index); // Shoot
			if(stuckIter < tryCount * 2)
				y += fieldDist; // Up
			else if(stuckIter < tryCount * 3)
				x += fieldDist; // Right
			else if(stuckIter < tryCount * 4)
				y -= fieldDist; // Down
			else if(stuckIter < tryCount * 5)
				x -= fieldDist; // Left
			else if(stuckIter < tryCount * 6)
				myTeam->speed(index, -1); // Drive in reverse
			else
				stuckIter = 0;
			fieldGen->addField(new PotentialField(x, y, fieldDist * 2, 0, 10, ATTRACT));
			cout << "TANK " << index << " STUCK!!! Set attractive field at (" << x << ", " << y << ")" << endl;
		}

		// Also repel recent history, walls, tanks, and probable obstacles
		repelHistory();
		fieldGen->createProbableObstacleRepel(gridFilter);
		fieldGen->createWallRepel();
		fieldGen->createTankRepel();
	}

	/*
	 * @return true iff tank's last position is near target coordinates
	 */
	bool nearTarget()
	{
		int margin = 20;
		return (abs(xHistory.back() - xTarget) < margin) &&
			(abs(yHistory.back() - yTarget) < margin);
	}
	
	/*
	 * Advance the target
	 */ 	
	void advanceTarget()
	{
		int border = (int) floor(world->worldSize / 2.0);

		// Up and down
		if(goingUp) // UP
		{
			yTarget += 100; // Go up
			if(yTarget > border)
			{
				yTarget -= 100;
				goingUp = !goingUp; // Switch
			}
		}
		else // DOWN
		{
			yTarget -= 100; // Go down
			if(yTarget < (-1 * border))
			{
				yTarget += 100;
				goingUp = !goingUp; // Switch
			}
		}

		// Right and left
		if(goingRight) // RIGHT
		{
			xTarget += 100; // Go right
			if(xTarget > border)
			{
				xTarget = -50;
				yTarget = -50;
			}
		}
		else // LEFT
		{
			xTarget -= 100; // Go left
			if(xTarget < (-1 * border))
			{
				xTarget = 50;
				yTarget = 50;
			}
		}
	}
public:
	Tank(int i, BZRC* team, World* w)
	{
		index = i;
		world = w;
		myTeam = team;
		fieldGen = new FieldGenerator(myTeam, w);

		stuckIter = 0;
//		int border = (int) floor(w->worldSize / 2.0) - 50;

		switch(index % 4) // TODO start in center or in corners?
		{
			case 0:
				goingUp = true;
				goingRight = true;
//				yTarget = -1 * border;
//				xTarget = -1 * border;
				xTarget = -50;
				yTarget = -50;
				break;
			case 1:
				goingUp = true;
				goingRight = false;
//				yTarget = -1 * border;
//				xTarget = border;
				xTarget = 50;
				yTarget = -50;
				break;
			case 2:
				goingUp = false;
				goingRight = true;
//				yTarget = border;
//				xTarget = -1 * border;
				xTarget = -50;
				yTarget = 50;
				break;
			case 3:
				goingUp = false;
				goingRight = false;
//				yTarget = border;
//				xTarget = border;
				xTarget = 50;
				yTarget = 50;
				break;
		}
	}

	~Tank()
	{
		delete fieldGen;
	}
	
	/*
	 * Clear all fields for this tank and reload
	 * them again based on the obstacles in the grid filter
	 * and where the tank should go to search
	 */
	void reloadFields(GridFilter* gridFilter)
	{
		// Reload fields to search for obstacles
		fieldGen->reloadSearchFields(gridFilter, index);

		// If stuck, try to get unstuck
		if(isStuck())
		{
			getUnstuck(gridFilter);
			stuckIter++;
		}
		else
		{
			stuckIter = 0;
		}

		// If tank is near target or target is probably an obstacle, advance target
		int border = (int) floor(world->worldSize / 2.0);
		cout << "Tank " << index << " Target " << xTarget << ", " << yTarget << " is probable obstacle: ";
		cout << gridFilter->isProbableObstacle(xTarget + border, yTarget + border) << endl;
		if(nearTarget() || gridFilter->isProbableObstacle(xTarget+border, yTarget+border))
		{
			advanceTarget();
			cout << "Tank " << index << " Advance Target" << endl;
		}
		fieldGen->addField(new PotentialField(xTarget, yTarget, world->worldSize * 2, 0, 2, ATTRACT));
		cout << "-----Target attract tank " << index << ": " << xTarget << ", " << yTarget << endl;
	}

	/*
	 * Add position history
	 */
	void addHistory(int x, int y)
	{
		xHistory.push_back(x);
		yHistory.push_back(y);
	}

	/*
	 * Get the target angle defined by this tank's potential fields
	 */
	double getTargetAngle(int x, int y)
	{
		return fieldGen->getVectorComponents(x, y);
	}
};


/*
 * Lab 1 functions for really dumb agents
 * These are all more or less pointless
 */
void printTank(tank_t* tank);
void moveTank(BZRC* myTeam, int index, double maxSpeed, int waitTime);

void printTank(tank_t* tank)
{
	cout << "Index: " << tank->index << endl;
	cout << "Position: " << tank->pos[0] << ", " << tank->pos[1] << endl;
	cout << "Velocity: " << tank->velocity[0] << ", " << tank->velocity[1] << endl;
	cout << "Angle: " << tank->angle << endl;
	cout << "Ang Velocity: " << tank->angvel << endl;
}

void moveTankTime(BZRC* myTeam, int index, double maxSpeed, useconds_t waitTime)
{
	while(!myTeam->speed(index, maxSpeed));
	usleep(waitTime);
	while(!myTeam->speed(index, 0));
}

void turnTankTime(BZRC* myTeam, int index, double maxAngVelocity, useconds_t waitTime)
{
	while(!myTeam->angvel(index, maxAngVelocity));
	usleep(waitTime);
	while(!myTeam->angvel(index, 0));
}
