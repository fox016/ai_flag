
class FieldGenerator
{
private:
	World* world;
	BZRC* myTeam;
	vector<PotentialField*> fields;
	int refreshCount;

	/*
	 * Draw potential fields
	 */ 	
	void drawFields(ostream& os)
	{
		int half = (int) floor(world->worldSize / 2.0);
		os << "set xrange [-" << half << ": " << half << "]" << endl;
		os << "set yrange [-" << half << ": " << half << "]" << endl;
		os << "unset key" << endl;
		os << "set size square" << endl << endl;
		os << "unset arrow" << endl;
		os << "plot '-' with vectors head" << endl;
	
		int x, y;
		for(x = (half * -1); x <= half; x += 20)
		{
			for(y = (half * -1); y <= half; y += 20)
			{
				double xPart = 0;
				double yPart = 0;
				unsigned int i;
				for(i = 0; i < fields.size(); i++)
				{
					double xComp, yComp;
					fields[i]->CalculateVectorComponents(x, y, xComp, yComp);
					xPart += xComp;
					yPart += yComp;
				}
				xPart *= 20;
				yPart *= 20;
				os << x << " " << y << " " << xPart << " " << yPart << endl;
			}
		}
		os << "e" << endl;
	}

	/*
	 * Make repulsive and tangential fields for all obstacles
	 */
	void createObstacleRepel()
	{
		vector<obstacle_t> obstacles;
		while(!myTeam->get_obstacles(&obstacles));

		unsigned int i;
		unsigned int j;
		for(i = 0; i < obstacles.size(); i++)
		{
			obstacle_t obs = obstacles[i];
			for(j = 0; j < MAX_OBSTACLE_CORNERS; j++)
			{
				if(obs.o_corner[j][0] < 1 && obs.o_corner[j][0] > 0 &&
					obs.o_corner[j][1] < 1 && obs.o_corner[j][1] > 0)
				{
					break;
				}
				fields.push_back(new PotentialField(obs.o_corner[j][0],
					obs.o_corner[j][1], 50, 0, 0.5, REPEL));
				fields.push_back(new PotentialField(obs.o_corner[j][0],
					obs.o_corner[j][1], 60, 0, 0.5, TANGENT_LEFT));
			}
		}
	}

	/*
	 * If I do not have an enemy flag, create attraction to enemy flag
	 */
	void createFlagAttract()
	{
		vector <flag_t> flags;
		while(!myTeam->get_flags(&flags));
		flag_t enemyFlag;

		// Find enemy flag
		unsigned int i;
		for(i = 0; i < flags.size(); i++)
		{
			if(flags[i].color != world->teamColor)
			{
				enemyFlag = flags[i];
				break;
			}
		}

		fields.push_back(new PotentialField(enemyFlag.pos[0],
			enemyFlag.pos[1], world->worldSize*2, 0.0, 2.0, ATTRACT));
	}

	/*
	 * Creates attractive field for home base
	 */
	void createBaseAttract()
	{
		vector <base_t> bases;
		while(!myTeam->get_bases(&bases));

		unsigned int i, j;
		for(i = 0; i < bases.size(); i++)
		{
			if(bases[i].color == world->teamColor)
			{
				for(j = 0; j < 4; j++)
				{ 
					fields.push_back(new PotentialField(bases[i].base_corner[j][0],
						bases[i].base_corner[j][1], world->worldSize*2, 0.0, 0.25, ATTRACT));
				}
				return;
			}
		}
	}

	/*
	 * Returns true iff I have an enemy flag
	 */
	bool hasEnemyFlag()
	{
		vector <flag_t> flags;
		while(!myTeam->get_flags(&flags));

		unsigned int i;
		for(i = 0; i < flags.size(); i++)
		{
			if(flags[i].poss_color == world->teamColor)
			{
				return true;
			}
		}
		return false;
	}

public:

	/*
	 * Constructor
	 * @param team - used to communicate with server
	 * @param fieldList - list of fields this generator affects
	 */
	FieldGenerator(BZRC* team, World* w)
	{
		myTeam = team;
		world = w;
		refreshCount = 0;
	}

	/*
	 * Destructor
	 */
	~FieldGenerator()
	{
		freeFields();
	}

	/*
 	 * Reload fields to search for obstacles
 	 */
	void reloadSearchFields(GridFilter* gridFilter, int index)
	{
		refreshCount++;
//		cout << "Refresh count: " << refreshCount << endl;
		
		if(refreshCount > 15)
		{
			filebuf fb;
			char filename[40];
			bzero(filename, 40);
			sprintf(filename, "potential_fields_%d.gpi", index);
			fb.open(filename, std::ios::out);
			ostream os(&fb);
			drawFields(os);
			refreshCount = 0;
		}

		freeFields();
		fields.clear();
	}

	/*
	 * Add potential field
	 */
	void addField(PotentialField* field)
	{
		fields.push_back(field);
	}

	/*
	 * Make repulsive and tangential fields for all tanks
	 */
	void createTankRepel()
	{
		vector<tank_t> myTanks;
		vector<otank_t> otherTanks;
		while(!myTeam->get_mytanks(&myTanks));
		while(!myTeam->get_othertanks(&otherTanks));

		// Repel other tanks
		unsigned int i;
		for(i = 0; i < otherTanks.size(); i++)
		{
			otank_t avoidTank = otherTanks[i];
			fields.push_back(new PotentialField(avoidTank.pos[0],
				avoidTank.pos[1], world->tankRadius*2, 0, 0.5, TANGENT_LEFT));
		}
		
		// Repel own tanks
		for(i = 0; i < myTanks.size(); i++)
		{
			tank_t avoidTank = myTanks[i];
			fields.push_back(new PotentialField(avoidTank.pos[0],
				avoidTank.pos[1], world->tankRadius*2, world->tankRadius, 0.5, TANGENT_LEFT));
		}
	}

	/*
	 * Reload all potential fields for obstacles, tanks, and goals
	 */
	void reloadFields()
	{
		freeFields();
		fields.clear();

		// Create repulsive/tangential fields for all obstacles
		createObstacleRepel();
		
		// Create repulsive/tangential fields for all tanks
		createTankRepel();
		
		// Create attractive field for an enemy flag (or own base if I have an enemy flag)
		if(!hasEnemyFlag())
			createFlagAttract();
		else
			createBaseAttract();
	}

	/*
	 * Repel world borders
	 */ 	
	void createWallRepel()
	{
		int edge = (int) floor(world->worldSize / 2.0);
		fields.push_back(new PotentialField(edge, 0, 20, 0, 1.5, WALL));
		fields.push_back(new PotentialField(edge * -1, 0, 20, 0, 1.5, WALL));
		fields.push_back(new PotentialField(0, edge, 20, 0, 1.5, WALL));
		fields.push_back(new PotentialField(0, edge * -1, 20, 0, 1.5, WALL));
	}

	/*
	 * Make repulsive and tangential fields for all probably obstacles
	 *
	 * @param gridFilter - use to get locations of probable obstacles
	 */ 	
	void createProbableObstacleRepel(GridFilter* gridFilter)
	{
		int x, y;
		int worldPosX, worldPosY;
		for(x = 0; x < world->worldSize; x++)
		{
			for(y = 0; y < world->worldSize; y++)
			{
				if(gridFilter->isProbableObstacle(x, y))
				{
					worldPosX = (int) (x - floor(world->worldSize / 2.0));
					worldPosY = (int) (y - floor(world->worldSize / 2.0));
//					cout << "Prob obstacle at " << worldPosX << ", " << worldPosY << endl;
					fields.push_back(new PotentialField(worldPosX, worldPosY, 20, 0, 0.1, REPEL));
					fields.push_back(new PotentialField(worldPosX, worldPosY, 25, 0, 0.1, TANGENT_LEFT));
				}
			}
		}
	}

	/*
	 * Free memory for all fields
	 */
	void freeFields()
	{
		unsigned int i;
		for(i = 0; i < fields.size(); i++)
			delete fields[i];
	}

	/*
	 * Get the angle of the vector acting on an agent
	 * at postion (x, y), taking all potential fiends into account
	 */
	double getVectorComponents(double x, double y)
	{
		double angle;
		double xPart = 0;
		double yPart = 0;
		unsigned int i;
		for(i = 0; i < fields.size(); i++)
		{
			double xComp, yComp;
			fields[i]->CalculateVectorComponents(x, y, xComp, yComp);
			xPart += xComp;
			yPart += yComp;
		}

		angle = atan2(yPart, xPart);
		if(angle < 0) angle += 2*PI;

		return angle;
	}
};
