class World
{
public:
	int tankRadius;
	string teamColor;	

	int worldSize;

	double truePositive;
	double trueNegative;

	World(BZRC* myTeam)
	{
		tankRadius = atoi(myTeam->getConstantByName("tankradius").c_str());
		teamColor = myTeam->getConstantByName("team");
		worldSize = atoi(myTeam->getConstantByName("worldsize").c_str());
		truePositive = atof(myTeam->getConstantByName("truepositive").c_str());
		trueNegative = atof(myTeam->getConstantByName("truenegative").c_str());
	}
};
